package prolab8;

import java.util.ArrayList;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class HammaddeScreen extends javax.swing.JDialog {
    
    DefaultTableModel model; // Model Oluştur
    Functions function = new Functions(); // Veritabani islemleri

    public HammaddeScreen(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model = (DefaultTableModel) hammaddeTablosu.getModel();
        hammaddeGoruntule();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        fAdi = new javax.swing.JTextField();
        hAdi = new javax.swing.JTextField();
        hStok = new javax.swing.JTextField();
        hFiyat = new javax.swing.JTextField();
        hUT = new javax.swing.JTextField();
        hSKT = new javax.swing.JTextField();
        hammaddeOlustur = new javax.swing.JButton();
        hammaddeDuzenle = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        alinacakUrunAdi = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        alinacakUrunStok = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        hammaddeTablosu = new javax.swing.JTable();
        mesajAlani = new javax.swing.JLabel();
        hammaddeSatinAl = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Hammadde İşlemleri");

        jLabel2.setText("Firma İsmi:");

        jLabel3.setText("Adı:");

        jLabel4.setText("Stok:");

        jLabel5.setText("Fiyat:");

        jLabel6.setText("Üretim Tarihi:");

        jLabel7.setText("Raf Ömrü(yıl):");

        hammaddeOlustur.setText("Hammadde Oluştur");
        hammaddeOlustur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hammaddeOlusturActionPerformed(evt);
            }
        });

        hammaddeDuzenle.setText("Hammadde Düzenle");
        hammaddeDuzenle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hammaddeDuzenleActionPerformed(evt);
            }
        });

        jLabel8.setText("Alınacak Ürün Adı:");

        jLabel9.setText("Alınacak Ürün Stok:");

        hammaddeTablosu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Firma İsmi", "Adı", "Stok", "Fiyat", "Kargo", "Üretim Tarihi", "Raf Ömrü(yıl)"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        hammaddeTablosu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hammaddeTablosuMouseClicked(evt);
            }
        });
        hammaddeTablosu.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                hammaddeTablosuKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(hammaddeTablosu);
        if (hammaddeTablosu.getColumnModel().getColumnCount() > 0) {
            hammaddeTablosu.getColumnModel().getColumn(0).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(1).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(2).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(3).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(4).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(5).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(6).setResizable(false);
            hammaddeTablosu.getColumnModel().getColumn(7).setResizable(false);
        }

        mesajAlani.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        mesajAlani.setForeground(new java.awt.Color(255, 0, 0));

        hammaddeSatinAl.setText("Hammadde Satın Al");
        hammaddeSatinAl.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hammaddeSatinAlActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mesajAlani, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator1)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(hammaddeOlustur, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(hammaddeDuzenle, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 223, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(alinacakUrunAdi, javax.swing.GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE)
                                .addComponent(alinacakUrunStok))
                            .addComponent(hammaddeSatinAl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fAdi, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(hAdi, javax.swing.GroupLayout.DEFAULT_SIZE, 230, Short.MAX_VALUE)
                                        .addComponent(hUT)
                                        .addComponent(hSKT)
                                        .addComponent(hStok, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(hFiyat)))))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(fAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(alinacakUrunAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(hAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(alinacakUrunStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(hStok, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(hammaddeSatinAl))
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(hFiyat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(hUT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(hSKT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hammaddeOlustur)
                    .addComponent(hammaddeDuzenle))
                .addGap(16, 16, 16)
                .addComponent(mesajAlani)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void hammaddeGoruntule(){
        
        model.setRowCount(0); // Tablo başlangıçta sıfır olsun
        
        ArrayList<Hammadde> hammaddeler = new ArrayList<Hammadde>();
        
        hammaddeler = function.hammaddeGetir();
        
        if (hammaddeler != null ) {
            for (Hammadde hammadde : hammaddeler) {
                Object[] eklenecek = {hammadde.getHammaddeID(),hammadde.getFirmaAdi(),hammadde.getHammaddeAdi(),hammadde.getHammaddeStok(),hammadde.getHammaddeFiyat(),hammadde.getHammaddeKargo(),hammadde.getHammaddeUT(),hammadde.getHammadeSKT()};
                
                model.addRow(eklenecek);
            }
        }
    
    }
    
    private void hammaddeOlusturActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hammaddeOlusturActionPerformed
        
        mesajAlani.setText("");
        
        String firmaAdi = fAdi.getText();
        String hammaddeAdi = hAdi.getText();
        int hammaddeStok = Integer.parseInt(hStok.getText());
        float hammaddeFiyat = Float.parseFloat(hFiyat.getText());
        String hammaddeUT = hUT.getText();
        int hammaddeSKT = Integer.parseInt(hSKT.getText());
        
        function.hammaddeEkle(firmaAdi,hammaddeAdi,hammaddeStok,hammaddeFiyat,hammaddeUT,hammaddeSKT);
        
        hammaddeGoruntule();
        
        mesajAlani.setText("Hammadde başarılı bir şekilde eklenmiştir.");
    }//GEN-LAST:event_hammaddeOlusturActionPerformed
    
    private void hammaddeTablosuKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hammaddeTablosuKeyReleased
       
        // Pasife cekildi.
    }//GEN-LAST:event_hammaddeTablosuKeyReleased

    private void hammaddeTablosuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hammaddeTablosuMouseClicked
        
        int selectedRow = hammaddeTablosu.getSelectedRow();
        
        fAdi.setText(model.getValueAt(selectedRow, 1).toString());
        hAdi.setText(model.getValueAt(selectedRow, 2).toString());
        hStok.setText(model.getValueAt(selectedRow, 3).toString());
        hFiyat.setText(model.getValueAt(selectedRow, 4).toString());
        hUT.setText(model.getValueAt(selectedRow, 6).toString());
        hSKT.setText(model.getValueAt(selectedRow, 7).toString());
    }//GEN-LAST:event_hammaddeTablosuMouseClicked

    private void hammaddeDuzenleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hammaddeDuzenleActionPerformed
        
        String firmaAdi = fAdi.getText();
        String hammaddeAdi = hAdi.getText();
        int hammaddeStok = Integer.parseInt(hStok.getText());
        float hammaddeFiyat = Float.parseFloat(hFiyat.getText());
        String hammaddeUT = hUT.getText();
        int hammaddeSKT = Integer.parseInt(hSKT.getText());
        
        int selectedRow = hammaddeTablosu.getSelectedRow();
        
        if(selectedRow == -1){
            if(model.getRowCount() == 0){
                mesajAlani.setText("Hammadde tablosu şu anda boş.");
            }else{
                mesajAlani.setText("Güncellenecek hammaddeyi seçiniz.");
            }
        }else{
            int id = (int)model.getValueAt(selectedRow, 0);
            
            function.hammaddeDuzenle(id,firmaAdi,hammaddeAdi,hammaddeStok,hammaddeFiyat,hammaddeUT,hammaddeSKT);
            hammaddeGoruntule();
            mesajAlani.setText("Hammadde düzenlenmiştir.");
        }
    }//GEN-LAST:event_hammaddeDuzenleActionPerformed

    private void hammaddeSatinAlActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hammaddeSatinAlActionPerformed
        
        String hammaddeAdi = alinacakUrunAdi.getText();
        int hammaddeStok = Integer.parseInt(alinacakUrunStok.getText());
        
        function.hammaddeSatinAl(hammaddeAdi,hammaddeStok);
        hammaddeGoruntule();
        mesajAlani.setText("Hammadde satın alınmıştır.");
    }//GEN-LAST:event_hammaddeSatinAlActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HammaddeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HammaddeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HammaddeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HammaddeScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                HammaddeScreen dialog = new HammaddeScreen(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField alinacakUrunAdi;
    private javax.swing.JTextField alinacakUrunStok;
    private javax.swing.JTextField fAdi;
    private javax.swing.JTextField hAdi;
    private javax.swing.JTextField hFiyat;
    private javax.swing.JTextField hSKT;
    private javax.swing.JTextField hStok;
    private javax.swing.JTextField hUT;
    private javax.swing.JButton hammaddeDuzenle;
    private javax.swing.JButton hammaddeOlustur;
    private javax.swing.JButton hammaddeSatinAl;
    private javax.swing.JTable hammaddeTablosu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel mesajAlani;
    // End of variables declaration//GEN-END:variables
}
