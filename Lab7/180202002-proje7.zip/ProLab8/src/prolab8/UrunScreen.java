package prolab8;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class UrunScreen extends javax.swing.JDialog {
    
    DefaultTableModel model; // Model Oluştur
    Functions function = new Functions(); // Veritabani islemleri

    public UrunScreen(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model = (DefaultTableModel) urunTablosu.getModel();
        urunGoruntule();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        urunTablosu = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        bAdi = new javax.swing.JTextField();
        bIcerik = new javax.swing.JTextField();
        bMiktar = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        urunTanimla = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        uAdi = new javax.swing.JTextField();
        uMiktar = new javax.swing.JTextField();
        urunOlustur = new javax.swing.JButton();
        mesajAlani = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Kimyasal Ürün İşlemleri");

        urunTablosu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Ürün Adı", "Ürün Stok", "Bileşen İsimleri", "Bileşen Miktarları", "İşçilik Maliyet", "Toplam Maliyet", "Satış Fiyatı", "Üretim Tarihi", "Raf Ömrü"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(urunTablosu);
        if (urunTablosu.getColumnModel().getColumnCount() > 0) {
            urunTablosu.getColumnModel().getColumn(0).setResizable(false);
            urunTablosu.getColumnModel().getColumn(1).setResizable(false);
            urunTablosu.getColumnModel().getColumn(2).setResizable(false);
            urunTablosu.getColumnModel().getColumn(3).setResizable(false);
            urunTablosu.getColumnModel().getColumn(4).setResizable(false);
            urunTablosu.getColumnModel().getColumn(5).setResizable(false);
            urunTablosu.getColumnModel().getColumn(6).setResizable(false);
            urunTablosu.getColumnModel().getColumn(7).setResizable(false);
            urunTablosu.getColumnModel().getColumn(8).setResizable(false);
            urunTablosu.getColumnModel().getColumn(9).setResizable(false);
        }

        jLabel2.setText("Ürün Adı:");

        jLabel3.setText("Ürün İçeriği:");

        jLabel4.setText("Ürün İçerik Miktarı:");

        jLabel5.setText("(Örn: Amonyak)");

        jLabel6.setText("(Örn: N,H)");

        jLabel7.setText("(Örn: 1,3)");

        urunTanimla.setText("Ürün Tanımla");
        urunTanimla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                urunTanimlaActionPerformed(evt);
            }
        });

        jLabel8.setText("Üretilecek Ürün Adı:");

        jLabel9.setText("Üretilecek Ürün Miktarı:");

        urunOlustur.setText("Kimyasal Ürün Oluştur");
        urunOlustur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                urunOlusturActionPerformed(evt);
            }
        });

        mesajAlani.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        mesajAlani.setForeground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 680, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(urunTanimla, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3))
                                        .addGap(49, 49, 49)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(bAdi, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                                            .addComponent(bIcerik)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addGap(18, 18, 18)
                                        .addComponent(bMiktar)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addGap(19, 19, 19)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(uMiktar)
                                    .addComponent(uAdi)))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(urunOlustur)))
                        .addGap(20, 20, 20))
                    .addComponent(mesajAlani, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(bAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8)
                    .addComponent(uAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(bIcerik, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel9)
                    .addComponent(uMiktar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(bMiktar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(urunOlustur))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(urunTanimla)
                .addGap(5, 5, 5)
                .addComponent(mesajAlani)
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void urunGoruntule(){
        
        model.setRowCount(0); // Tablo başlangıçta sıfır olsun
        
        ArrayList<Urun> urunler = new ArrayList<Urun>();
        
        urunler = function.urunGetir();
        
        if (urunler != null ) {
            for (Urun urun : urunler) {
                Object[] eklenecek = {urun.getUrunID(),urun.getUrunAdi(),urun.getUrunStok(),urun.getUrunBilesenIsimleri(),urun.getUrunBilesenMiktarlari(),urun.getUrunIscilikMaliyeti(),urun.getUrunMaliyeti(),urun.getUrunSatisFiyati(),urun.getUrunUT(),urun.getUrunSKT()};
                
                model.addRow(eklenecek);
            }
        }
    
    }
    
    private void urunTanimlaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_urunTanimlaActionPerformed
        
        mesajAlani.setText("");
        
        String urunAdi = bAdi.getText();
        String urunBilesenIcerik = bIcerik.getText();
        String UrunBilesenMiktar = bMiktar.getText();
        
        function.urunTanimla(urunAdi,urunBilesenIcerik,UrunBilesenMiktar);
        
        urunGoruntule();
        
        mesajAlani.setText("Ürün başarılı bir şekilde eklenmiştir.");
    }//GEN-LAST:event_urunTanimlaActionPerformed

    private void urunOlusturActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_urunOlusturActionPerformed
        
        mesajAlani.setText("");
        
        String urunAdi = uAdi.getText();
        int  urunAdet = Integer.parseInt(uMiktar.getText());
        
        if(function.urunOlustur(urunAdi,urunAdet)!=0){
            urunGoruntule();
            mesajAlani.setText("OK!");
        }else{
            urunGoruntule();
            mesajAlani.setText("Hata!");
        }
    }//GEN-LAST:event_urunOlusturActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UrunScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UrunScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UrunScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UrunScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UrunScreen dialog = new UrunScreen(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bAdi;
    private javax.swing.JTextField bIcerik;
    private javax.swing.JTextField bMiktar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel mesajAlani;
    private javax.swing.JTextField uAdi;
    private javax.swing.JTextField uMiktar;
    private javax.swing.JButton urunOlustur;
    private javax.swing.JTable urunTablosu;
    private javax.swing.JButton urunTanimla;
    // End of variables declaration//GEN-END:variables
}
