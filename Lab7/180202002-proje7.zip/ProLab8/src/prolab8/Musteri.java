package prolab8;

public class Musteri {
    private int musteriID;
    private String musteriAdi;
    private String musteriAdres;

    public Musteri(int musteriID, String musteriAdi, String musteriAdres) {
        this.musteriID = musteriID;
        this.musteriAdi = musteriAdi;
        this.musteriAdres = musteriAdres;
    }

    public int getMusteriID() {
        return musteriID;
    }

    public void setMusteriID(int musteriID) {
        this.musteriID = musteriID;
    }

    public String getMusteriAdi() {
        return musteriAdi;
    }

    public void setMusteriAdi(String musteriAdi) {
        this.musteriAdi = musteriAdi;
    }

    public String getMusteriAdres() {
        return musteriAdres;
    }

    public void setMusteriAdres(String musteriAdres) {
        this.musteriAdres = musteriAdres;
    }
    
    
}
