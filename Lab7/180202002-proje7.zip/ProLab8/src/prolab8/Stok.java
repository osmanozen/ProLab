package prolab8;

public class Stok {
    private int stokID;
    private String stokAdi;
    private int stokStok;
    private float stokFiyat;
    private String stokUT;
    private int stokSKT;

    public Stok(int stokID, String stokAdi, int stokStok, float stokFiyat, String stokUT, int stokSKT) {
        this.stokID = stokID;
        this.stokAdi = stokAdi;
        this.stokStok = stokStok;
        this.stokFiyat = stokFiyat;
        this.stokUT = stokUT;
        this.stokSKT = stokSKT;
    }

    public int getStokID() {
        return stokID;
    }

    public void setStokID(int stokID) {
        this.stokID = stokID;
    }

    public String getStokAdi() {
        return stokAdi;
    }

    public void setStokAdi(String stokAdi) {
        this.stokAdi = stokAdi;
    }

    public int getStokStok() {
        return stokStok;
    }

    public void setStokStok(int stokStok) {
        this.stokStok = stokStok;
    }

    public float getStokFiyat() {
        return stokFiyat;
    }

    public void setStokFiyat(float stokFiyat) {
        this.stokFiyat = stokFiyat;
    }

    public String getStokUT() {
        return stokUT;
    }

    public void setStokUT(String stokUT) {
        this.stokUT = stokUT;
    }

    public int getStokSKT() {
        return stokSKT;
    }

    public void setStokSKT(int stokSKT) {
        this.stokSKT = stokSKT;
    }
    
    
}
