package prolab8;

public class Siparis {
    private String musteriAdi;
    private String siparisAdi;
    private int siparisMiktari;
    private float siparisMaliyet;
    private float siparisSatisFiyati;
    private float siparisKari;

    public Siparis(String musteriAdi, String siparisAdi, int siparisMiktari, float siparisMaliyet, float siparisSatisFiyati, float siparisKari) {
        this.musteriAdi = musteriAdi;
        this.siparisAdi = siparisAdi;
        this.siparisMiktari = siparisMiktari;
        this.siparisMaliyet = siparisMaliyet;
        this.siparisSatisFiyati = siparisSatisFiyati;
        this.siparisKari = siparisKari;
    }

    public String getMusteriAdi() {
        return musteriAdi;
    }

    public void setMusteriAdi(String musteriAdi) {
        this.musteriAdi = musteriAdi;
    }

    public String getSiparisAdi() {
        return siparisAdi;
    }

    public void setSiparisAdi(String siparisAdi) {
        this.siparisAdi = siparisAdi;
    }

    public int getSiparisMiktari() {
        return siparisMiktari;
    }

    public void setSiparisMiktari(int siparisMiktari) {
        this.siparisMiktari = siparisMiktari;
    }

    public float getSiparisMaliyet() {
        return siparisMaliyet;
    }

    public void setSiparisMaliyet(float siparisMaliyet) {
        this.siparisMaliyet = siparisMaliyet;
    }

    public float getSiparisSatisFiyati() {
        return siparisSatisFiyati;
    }

    public void setSiparisSatisFiyati(float siparisSatisFiyati) {
        this.siparisSatisFiyati = siparisSatisFiyati;
    }

    public float getSiparisKari() {
        return siparisKari;
    }

    public void setSiparisKari(float siparisKari) {
        this.siparisKari = siparisKari;
    }
    
    
    
}
