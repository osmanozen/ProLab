package prolab8;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class SiparisScreen extends javax.swing.JDialog {
    
    DefaultTableModel model; // Model Oluştur
    Functions function = new Functions(); // Veritabani islemleri
    
    public SiparisScreen(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        model = (DefaultTableModel) siparisTablosu.getModel();
        siparisGoruntule(); // Her zaman tablo gosterilsin
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        mAdi = new javax.swing.JTextField();
        kAdi = new javax.swing.JTextField();
        kMiktar = new javax.swing.JTextField();
        sOlustur = new javax.swing.JButton();
        mesajAlani = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        siparisTablosu = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("Sipariş İşlemleri");

        jLabel2.setText("Müşteri Adı:");

        jLabel3.setText("Kimyasal Ürün Adı:");

        jLabel4.setText("Kimyasal Ürün Miktarı:");

        sOlustur.setText("Sipariş Oluştur");
        sOlustur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sOlusturActionPerformed(evt);
            }
        });

        mesajAlani.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        mesajAlani.setForeground(new java.awt.Color(255, 0, 0));

        siparisTablosu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Müşteri Adı", "Sipariş Adı", "Sipariş Miktarı", "Sipariş Maliyeti", "Sipariş Satış Fiyatı", "Sipariş Kârı"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(siparisTablosu);
        if (siparisTablosu.getColumnModel().getColumnCount() > 0) {
            siparisTablosu.getColumnModel().getColumn(0).setResizable(false);
            siparisTablosu.getColumnModel().getColumn(1).setResizable(false);
            siparisTablosu.getColumnModel().getColumn(2).setResizable(false);
            siparisTablosu.getColumnModel().getColumn(3).setResizable(false);
            siparisTablosu.getColumnModel().getColumn(4).setResizable(false);
            siparisTablosu.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3)
                                            .addComponent(jLabel4))
                                        .addGap(19, 19, 19)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(mAdi)
                                            .addComponent(kAdi)
                                            .addComponent(kMiktar, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(105, 105, 105)
                                .addComponent(sOlustur, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(mesajAlani))
                        .addGap(0, 66, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(mAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sOlustur))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(kAdi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kMiktar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addComponent(mesajAlani)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sOlusturActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sOlusturActionPerformed
        mesajAlani.setText("");
        
        String musteriAdi = mAdi.getText();
        String urunAdi = kAdi.getText();
        int urunMiktar = Integer.parseInt(kMiktar.getText());
        
        function.siparisEkle(musteriAdi,urunAdi,urunMiktar);
        
        siparisGoruntule();
        mesajAlani.setText("Sipariş başarılı bir şekilde eklenmiştir.");
    }//GEN-LAST:event_sOlusturActionPerformed

    
    public void siparisGoruntule(){
        
        model.setRowCount(0); // Tablo başlangıçta sıfır olsun
        
        ArrayList<Siparis> siparisler = new ArrayList<Siparis>();
        
        siparisler = function.siparisGetir();
        
        if (siparisler != null ) {
            for (Siparis siparis : siparisler) {
                Object[] eklenecek = {siparis.getMusteriAdi(),siparis.getSiparisAdi(),siparis.getSiparisMiktari(),siparis.getSiparisMaliyet(),siparis.getSiparisSatisFiyati(),siparis.getSiparisKari()};
                
                model.addRow(eklenecek);
            }
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SiparisScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SiparisScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SiparisScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SiparisScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SiparisScreen dialog = new SiparisScreen(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField kAdi;
    private javax.swing.JTextField kMiktar;
    private javax.swing.JTextField mAdi;
    private javax.swing.JLabel mesajAlani;
    private javax.swing.JButton sOlustur;
    private javax.swing.JTable siparisTablosu;
    // End of variables declaration//GEN-END:variables
}
