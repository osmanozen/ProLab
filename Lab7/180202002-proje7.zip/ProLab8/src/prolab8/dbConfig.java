package prolab8;

public class dbConfig {
    public static final String host = "localhost";
    public static final String db_username = "root";
    public static final String db_password = "";
    public static final String db_name = "prolab23";
    public static final int port = 3306;
}
