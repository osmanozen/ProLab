package prolab8;

public class Tedarikci {
    private int firmaId;
    private String firmaAdi;
    private String firmaSehir;
    private String firmaKonum;
    private int firmaUzaklik;

    public Tedarikci(int firmaId, String firmaAdi, String firmaSehir, String firmaKonum, int firmaUzaklik) {
        this.firmaId = firmaId;
        this.firmaAdi = firmaAdi;
        this.firmaSehir = firmaSehir;
        this.firmaKonum = firmaKonum;
        this.firmaUzaklik = firmaUzaklik;
    }

    public int getFirmaId() {
        return firmaId;
    }

    public void setFirmaId(int firmaId) {
        this.firmaId = firmaId;
    }

    public String getFirmaAdi() {
        return firmaAdi;
    }

    public void setFirmaAdi(String firmaAdi) {
        this.firmaAdi = firmaAdi;
    }

    public String getFirmaSehir() {
        return firmaSehir;
    }

    public void setFirmaSehir(String firmaSehir) {
        this.firmaSehir = firmaSehir;
    }

    public String getFirmaKonum() {
        return firmaKonum;
    }

    public void setFirmaKonum(String firmaKonum) {
        this.firmaKonum = firmaKonum;
    }

    public int getFirmaUzaklik() {
        return firmaUzaklik;
    }

    public void setFirmaUzaklik(int firmaUzaklik) {
        this.firmaUzaklik = firmaUzaklik;
    }
    
    

    
}
