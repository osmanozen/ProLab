package prolab8;

public class Urun {
    private int urunID;
    private String urunAdi;
    private int urunStok;
    private String urunBilesenIsimleri;
    private String urunBilesenMiktarlari;
    private float urunIscilikMaliyeti;
    private float urunMaliyeti;
    private float urunSatisFiyati;
    private String urunUT;
    private int urunSKT;

    public Urun(int urunID, String urunAdi, int urunStok, String urunBilesenIsimleri, String urunBilesenMiktarlari, float urunIscilikMaliyeti, float urunMaliyeti, float urunSatisFiyati, String urunUT, int urunSKT) {
        this.urunID = urunID;
        this.urunAdi = urunAdi;
        this.urunStok = urunStok;
        this.urunBilesenIsimleri = urunBilesenIsimleri;
        this.urunBilesenMiktarlari = urunBilesenMiktarlari;
        this.urunIscilikMaliyeti = urunIscilikMaliyeti;
        this.urunMaliyeti = urunMaliyeti;
        this.urunSatisFiyati = urunSatisFiyati;
        this.urunUT = urunUT;
        this.urunSKT = urunSKT;
    }

    public int getUrunID() {
        return urunID;
    }

    public void setUrunID(int urunID) {
        this.urunID = urunID;
    }

    public String getUrunAdi() {
        return urunAdi;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public int getUrunStok() {
        return urunStok;
    }

    public void setUrunStok(int urunStok) {
        this.urunStok = urunStok;
    }

    public String getUrunBilesenIsimleri() {
        return urunBilesenIsimleri;
    }

    public void setUrunBilesenIsimleri(String urunBilesenIsimleri) {
        this.urunBilesenIsimleri = urunBilesenIsimleri;
    }

    public String getUrunBilesenMiktarlari() {
        return urunBilesenMiktarlari;
    }

    public void setUrunBilesenMiktarlari(String urunBilesenMiktarlari) {
        this.urunBilesenMiktarlari = urunBilesenMiktarlari;
    }

    public float getUrunIscilikMaliyeti() {
        return urunIscilikMaliyeti;
    }

    public void setUrunIscilikMaliyeti(float urunIscilikMaliyeti) {
        this.urunIscilikMaliyeti = urunIscilikMaliyeti;
    }

    public float getUrunMaliyeti() {
        return urunMaliyeti;
    }

    public void setUrunMaliyeti(float urunMaliyeti) {
        this.urunMaliyeti = urunMaliyeti;
    }

    public float getUrunSatisFiyati() {
        return urunSatisFiyati;
    }

    public void setUrunSatisFiyati(float urunSatisFiyati) {
        this.urunSatisFiyati = urunSatisFiyati;
    }

    public String getUrunUT() {
        return urunUT;
    }

    public void setUrunUT(String urunUT) {
        this.urunUT = urunUT;
    }

    public int getUrunSKT() {
        return urunSKT;
    }

    public void setUrunSKT(int urunSKT) {
        this.urunSKT = urunSKT;
    }

    
}
