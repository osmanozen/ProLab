package prolab8;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Functions {
    
    private Connection con = null;
    private PreparedStatement preparedStatement = null;
    private Statement statement = null;
    
    
    public Functions(){
        String url = "jdbc:mysql://" + dbConfig.host + ":" + dbConfig.port + "/" + dbConfig.db_name + "?useUnicode=true&characterEncoding=utf8";
        
        try{
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver bulunamadi.");
        }
        
        try {
            con = DriverManager.getConnection(url, dbConfig.db_username, dbConfig.db_password);
            System.out.println("Baglanti basarili...");
        } catch (SQLException ex) {
            System.out.println("Baglanti basarisiz...");
        }
    }
    
    public ArrayList<Musteri> musteriGetir(){
    
        ArrayList<Musteri> cikti = new ArrayList<Musteri>();
        
        try {
            statement = con.createStatement();
            
            String query = "SELECT * FROM musteriler";
            
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
            
                int mId = rs.getInt("musteri_id");
                String mAdi = rs.getString("musteri_adi");
                String mAdres = rs.getString("musteri_adres");
                
                cikti.add(new Musteri(mId,mAdi,mAdres));
            }
            
            return cikti;
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public void musteriEkle(String musteriAdi, String musteriAdres){
        
        String query = "INSERT INTO musteriler (musteri_adi,musteri_adres) VALUES (?,?)";
        
        try {
            preparedStatement = con.prepareStatement(query);
            
            preparedStatement.setString(1, musteriAdi);
            preparedStatement.setString(2, musteriAdres);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public ArrayList<Siparis> siparisGetir(){
    
        ArrayList<Siparis> cikti = new ArrayList<Siparis>();
        
        try {
            statement = con.createStatement();
            
            String query = "SELECT musteri_adi, siparis_adi, siparis_miktar, siparis_alis, siparis_satis FROM siparisler INNER JOIN musteriler ON musteri_adi = siparis_musteriAdi";
            
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
            
                
                String mAdi = rs.getString("musteri_adi");
                String sAdi = rs.getString("siparis_adi");
                int sMiktar = rs.getInt("siparis_miktar");
                float sMaliyet = rs.getFloat("siparis_alis");
                float sSatis = rs.getFloat("siparis_satis");
                float sKar = sSatis-sMaliyet;
                
                cikti.add(new Siparis(mAdi,sAdi,sMiktar,sMaliyet,sSatis,sKar));
            }
            
            return cikti;
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public void siparisEkle(String musteriAdi, String urunAdi, int urunMiktar){
        
        String query = "INSERT INTO siparisler (siparis_musteriAdi,siparis_adi,siparis_miktar,siparis_alis,siparis_satis) VALUES (?,?,?,?,?)";
        
        try {
            preparedStatement = con.prepareStatement(query);
            
            preparedStatement.setString(1, musteriAdi);
            preparedStatement.setString(2, urunAdi);
            preparedStatement.setInt(3, urunMiktar);
            preparedStatement.setFloat(4, 0);
            preparedStatement.setFloat(5, 0);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
       
    public ArrayList<Tedarikci> firmalariGetir(){
    
        ArrayList<Tedarikci> cikti = new ArrayList<Tedarikci>();
        
        try {
            statement = con.createStatement();
            
            String query = "SELECT tedarikciler.firma_id, tedarikciler.firma_ismi, tedarikciler.firma_sehir, mesafeler.firma_konum, mesafeler.firma_uzaklik FROM tedarikciler INNER JOIN mesafeler ON tedarikciler.firma_sehir = mesafeler.firma_sehir ORDER BY firma_id ASC";
            
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
            
                int firmaId = rs.getInt("firma_id");
                String firmaAdi = rs.getString("firma_ismi");
                String firmaSehir = rs.getString("firma_sehir");
                String firmaKonum = rs.getString("firma_konum");
                int firmaUzaklik = rs.getInt("firma_uzaklik");
                
                cikti.add(new Tedarikci(firmaId,firmaAdi,firmaSehir,firmaKonum,firmaUzaklik));
            }
            
            return cikti;
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public void firmaEkle(String firmaAdı, String firmaSehir){
        
        String query = "INSERT INTO tedarikciler (firma_ismi,firma_sehir) VALUES (?,?)";
        
        try {
            preparedStatement = con.prepareStatement(query);
            
            preparedStatement.setString(1, firmaAdı);
            preparedStatement.setString(2, firmaSehir);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public ArrayList<Hammadde> hammaddeGetir(){
    
        ArrayList<Hammadde> cikti = new ArrayList<Hammadde>();
        String id = "5";
        try {
            statement = con.createStatement();
            String query = "SELECT * FROM hammaddeler ORDER BY hammadde_fiyat ASC";
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
                int hammaddeID = rs.getInt("hammadde_id");
                String firmaAdi = rs.getString("firma_ismi");
                String hammaddeAdi = rs.getString("hammadde_adi");
                int hammaddeStok = rs.getInt("hammadde_stok");
                float hammaddeFiyat = rs.getFloat("hammadde_fiyat");
                float hammaddeKargo = rs.getFloat("hammade_kargo");
                String hammaddeUT = rs.getString("hammadde_ut");
                int hammaddeSKT = rs.getInt("hammadde_skt");
                
                cikti.add(new Hammadde(hammaddeID,firmaAdi,hammaddeAdi,hammaddeStok,hammaddeFiyat,hammaddeKargo,hammaddeUT,hammaddeSKT));
            }
            return cikti;
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public float kargoMasrafBul(String firmaAdi){
        try {
            statement = con.createStatement();
				
            String query = "SELECT tedarikciler.firma_ismi, mesafeler.firma_konum, mesafeler.firma_uzaklik FROM tedarikciler INNER JOIN mesafeler ON mesafeler.firma_sehir=tedarikciler.firma_sehir";
            
            ResultSet rs = statement.executeQuery(query);
            float hammaddeKargo = 0;
            
            while(rs.next()){
                String firmaKonum = rs.getString("firma_konum");
                if(firmaAdi.equals(rs.getString("firma_ismi"))){
                    if(firmaKonum.equals("Yurtici")){
                        hammaddeKargo = (float)rs.getInt("firma_uzaklik")/2;
                    }else
                        hammaddeKargo = (float)rs.getInt("firma_uzaklik");
                }
            }   
            return hammaddeKargo;   
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        }
    }
    
    public void hammaddeEkle(String firmaAdi, String hAdi, int hStok, float hFiyat, String hUT, int hSKT){
    
        String query = "INSERT INTO hammaddeler(firma_ismi,hammadde_adi,hammadde_stok,hammadde_fiyat,hammade_kargo,hammadde_ut,hammadde_skt) VALUES(?,?,?,?,?,?,?)";
        
        try {
            preparedStatement = con.prepareStatement(query);
            
            preparedStatement.setString(1, firmaAdi);
            preparedStatement.setString(2, hAdi);
            preparedStatement.setInt(3, hStok);
            preparedStatement.setFloat(4, hFiyat);
            preparedStatement.setFloat(5, kargoMasrafBul(firmaAdi));
            preparedStatement.setString(6, hUT);
            preparedStatement.setInt(7, hSKT);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void hammaddeDuzenle(int id, String firmaAdi, String hAdi, int hStok, float hFiyat, String hUT, int hSKT){
    
        String query = "UPDATE hammaddeler SET firma_ismi = ?, hammadde_adi = ?, hammadde_stok = ?, hammadde_fiyat = ?, hammade_kargo = ?, hammadde_ut = ?, hammadde_skt = ? WHERE hammadde_id = ?";
        
        try {
            preparedStatement = con.prepareStatement(query);
            
            preparedStatement.setString(1, firmaAdi);
            preparedStatement.setString(2, hAdi);
            preparedStatement.setInt(3, hStok);
            preparedStatement.setFloat(4, hFiyat);
            preparedStatement.setFloat(5, kargoMasrafBul(firmaAdi));
            preparedStatement.setString(6, hUT);
            preparedStatement.setInt(7, hSKT);
            preparedStatement.setInt(8, id);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void hammaddeSatinAl(String hAdi, int hStok){
        
        try {
            statement = con.createStatement();
            String query = "SELECT * FROM hammaddeler WHERE hammadde_adi=\""+hAdi+"\" ORDER BY hammadde_fiyat ASC";
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
                int hammaddeID = rs.getInt("hammadde_id");
                int hammaddeStok = rs.getInt("hammadde_stok");
                String hUT = rs.getString("hammadde_ut");
                int hSKT = rs.getInt("hammadde_skt");
                String firmaAdi = rs.getString("firma_ismi");                
                float hFiyat = rs.getFloat("hammadde_fiyat");
                
                Date now = new Date();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");    
                Date date = null;
                int saas = Integer.parseInt(hUT.substring(4, 8))+hSKT;
                String tarih = hUT.substring(0, 2)+"-"+hUT.substring(2, 4)+"-"+saas;

                try {
                    date = simpleDateFormat.parse(tarih);
                } catch (ParseException ex) {
                    Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                }
                
                if(hStok <= 0)
                    break;
                
                if(hammaddeStok>=hStok){
                    if(now.getTime() < date.getTime()){
                        int stok = hammaddeStok-hStok;

                        String query2 = "UPDATE hammaddeler SET hammadde_stok = ? WHERE hammadde_id = ?";

                        try {
                            preparedStatement = con.prepareStatement(query2);
                            preparedStatement.setInt(1, stok);
                            preparedStatement.setInt(2, hammaddeID);

                            preparedStatement.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        String query4 = "INSERT INTO stoktakiler(stoktaki_id,stoktaki_urunStok,stoktaki_urunFiyat) VALUES(?,?,?)";
            
                        try {
                            preparedStatement = con.prepareStatement(query4);

                            preparedStatement.setInt(1, hammaddeID);
                            preparedStatement.setInt(2, hStok);
                            preparedStatement.setFloat(3, hFiyat+(kargoMasrafBul(firmaAdi)/hStok));
                            
                            preparedStatement.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        hStok=0;
                    }
                }else{
                    if(now.getTime() < date.getTime()){
                        String query3 = "UPDATE hammaddeler SET hammadde_stok = ? WHERE hammadde_id = ?";

                        try {
                            preparedStatement = con.prepareStatement(query3);
                            preparedStatement.setInt(1, 0);
                            preparedStatement.setInt(2, hammaddeID);

                            preparedStatement.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        String query5 = "INSERT INTO stoktakiler(stoktaki_id,stoktaki_urunStok,stoktaki_urunFiyat) VALUES(?,?,?)";
            
                        try {
                            preparedStatement = con.prepareStatement(query5);

                            preparedStatement.setInt(1, hammaddeID);
                            preparedStatement.setInt(2, hammaddeStok);
                            preparedStatement.setFloat(3, hFiyat+(kargoMasrafBul(firmaAdi)/hammaddeStok));
                            
                            preparedStatement.executeUpdate();
                        } catch (SQLException ex) {
                            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                        }

                        hStok -= hammaddeStok;
                    }
                }
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public ArrayList<Stok> stokGetir(){
    
        ArrayList<Stok> cikti = new ArrayList<Stok>();
        
        try {
            statement = con.createStatement();
            
            String query = "SELECT stoktakiler.stoktaki_id, stoktakiler.stoktaki_urunStok, stoktakiler.stoktaki_urunFiyat, hammaddeler.hammadde_adi, hammaddeler.hammadde_ut, hammaddeler.hammadde_skt FROM stoktakiler INNER JOIN hammaddeler ON stoktakiler.stoktaki_id = hammaddeler.hammadde_id ORDER BY stoktaki_urunFiyat ASC";
            
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
            
                int stokID = rs.getInt("stoktaki_id");
                String stokAdi = rs.getString("hammadde_adi");
                int stokStok = rs.getInt("stoktaki_urunStok");
                float stokFiyat = rs.getFloat("stoktaki_urunFiyat");
                String stokUT = rs.getString("hammadde_ut");
                int stokSKT = rs.getInt("hammadde_skt");
                
                cikti.add(new Stok(stokID,stokAdi,stokStok,stokFiyat,stokUT,stokSKT));
            }
            
            return cikti;
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public ArrayList<Urun> urunGetir(){
    
        ArrayList<Urun> cikti = new ArrayList<Urun>();
        
        try {
            statement = con.createStatement();
            
            String query = "SELECT urunler.urun_id, urunler.urun_adi, urunler.urun_stok, bilesenler.bilesen_icerik, bilesenler.bilesen_miktar, urunler.urun_isciMaliyeti, urunler.urun_maliyeti, urunler.urun_satisFiyati, urunler.urun_UT, urunler.urun_SKT FROM urunler INNER JOIN bilesenler ON urunler.urun_adi = bilesenler.bilesen_adi";
            
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
            
                int urunID = rs.getInt("urun_id");
                String urunAdi = rs.getString("urun_adi");
                int urunStok = rs.getInt("urun_stok");
                String urunIcerik = rs.getString("bilesen_icerik");
                String urunMiktar = rs.getString("bilesen_miktar");
                float urunIscilikMaliyet = rs.getFloat("urun_isciMaliyeti");
                float urunMaliyet = rs.getFloat("urun_maliyeti");
                float urunSatisFiyati = rs.getFloat("urun_satisFiyati");
                String urunUT = rs.getString("urun_UT");
                int urunSKT = rs.getInt("urun_SKT");
                
                cikti.add(new Urun(urunID,urunAdi,urunStok,urunIcerik,urunMiktar,urunIscilikMaliyet,urunMaliyet,urunSatisFiyati,urunUT,urunSKT));
            }
            
            return cikti;
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public void urunTanimla(String urunAdi, String urunBilesenIcerik, String UrunBilesenMiktar){
    
        String query = "INSERT INTO bilesenler(bilesen_adi,bilesen_icerik,bilesen_miktar) VALUES(?,?,?)";
        
        try {
            preparedStatement = con.prepareStatement(query);
            
            preparedStatement.setString(1, urunAdi);
            preparedStatement.setString(2, urunBilesenIcerik);
            preparedStatement.setString(3, UrunBilesenMiktar);
            
            preparedStatement.executeUpdate();
            
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public int urunOlustur(String uAdi, int uAdet){
        
        String[] bilesenler = null;
        String[] miktarlar = null;
        int i, maliyet = 0, ut=0, sayac=0;
        
        try {
            statement = con.createStatement();
            String query = "SELECT * FROM bilesenler WHERE bilesen_adi=\""+uAdi+"\"";
            ResultSet rs = statement.executeQuery(query);
            
            while(rs.next()){
                String bilesen = rs.getString("bilesen_icerik");
                String miktar = rs.getString("bilesen_miktar");
                bilesenler = bilesen.split(",");
                miktarlar = miktar.split(",");
                
                for(i=0;i<bilesenler.length;i++){
                    sayac=0;
                    try {
                        statement = con.createStatement();
                        String query2 = "SELECT SUM(stoktaki_urunStok) AS stok FROM hammaddeler INNER JOIN stoktakiler ON stoktakiler.stoktaki_id = hammaddeler.hammadde_id INNER JOIN bilesenler ON bilesenler.bilesen_adi= hammaddeler.hammadde_adi WHERE bilesen_icerik =\""+bilesenler[i]+"\" GROUP BY bilesen_icerik";
                        ResultSet rs2 = statement.executeQuery(query2);

                        while(rs2.next()){
                            int bStok = rs2.getInt("stok");

                            if(bStok>=uAdet*Integer.parseInt(miktarlar[i]))
                                sayac=1;
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    if(sayac==0)
                        break;
                }
                
                if(sayac==0)
                    break;
                
                for(i=0;i<bilesenler.length;i++){
                    int iAdet = uAdet*Integer.parseInt(miktarlar[i]);
                    
                    try {
                        statement = con.createStatement();
                        String query3 = "SELECT * FROM hammaddeler INNER JOIN stoktakiler ON stoktakiler.stoktaki_id = hammaddeler.hammadde_id INNER JOIN bilesenler ON bilesenler.bilesen_adi= hammaddeler.hammadde_adi WHERE bilesen_icerik =\""+bilesenler[i]+"\" ORDER BY stoktaki_urunFiyat ASC";
                        ResultSet rs3 = statement.executeQuery(query3);

                        while(rs3.next()){
                            int stok = rs3.getInt("stoktaki_urunStok");
                            float fiyat = rs3.getFloat("stoktaki_urunFiyat");
                            int id = rs3.getInt("stoktaki_id");
                            
                            if(iAdet <= 0)
                                break;

                            if(stok>=iAdet){

                                String query4 = "UPDATE stoktakiler SET stoktaki_urunStok = ? WHERE stoktaki_id = ?";

                                try {
                                        preparedStatement = con.prepareStatement(query4);
                                        preparedStatement.setInt(1, stok-iAdet);
                                        preparedStatement.setInt(2, id);

                                        preparedStatement.executeUpdate();
                                } catch (SQLException ex) {
                                        Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                maliyet+=iAdet*fiyat;
                                iAdet=0;
                            }else{

                                String query4 = "UPDATE stoktakiler SET stoktaki_urunStok = ? WHERE stoktaki_id = ?";

                                try {
                                        preparedStatement = con.prepareStatement(query4);
                                        preparedStatement.setInt(1, 0);
                                        preparedStatement.setInt(2, id);

                                        preparedStatement.executeUpdate();
                                } catch (SQLException ex) {
                                        Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                maliyet+=stok*fiyat;
                                iAdet-=stok;
                            }
                            
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }    
        } catch (SQLException ex) {
            Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);  
        }
        
        
        
        if(sayac==0)
            return sayac;
        else{
            String query5 = "INSERT INTO urunler(urun_adi,urun_stok,urun_isciMaliyeti,urun_maliyeti,urun_satisFiyati,urun_UT,urun_SKT) VALUES(?,?,?,?,?,?,?)";
            
            try {
            preparedStatement = con.prepareStatement(query5);

            preparedStatement.setString(1, uAdi);
            preparedStatement.setInt(2, uAdet);
            preparedStatement.setFloat(3, uAdet);
            preparedStatement.setFloat(4, maliyet);
            preparedStatement.setFloat(5, ((uAdet+maliyet)*120)/100);
            preparedStatement.setString(6, "11111111");
            preparedStatement.setInt(7, 5);
            
            preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            String query6 = "UPDATE siparisler SET siparis_alis = ?, siparis_satis = ? WHERE siparis_adi = ?";

            try {
                    preparedStatement = con.prepareStatement(query6);
                    preparedStatement.setFloat(1, maliyet);
                    preparedStatement.setFloat(2, ((uAdet+maliyet)*120)/100);
                    preparedStatement.setString(3, uAdi);

                    preparedStatement.executeUpdate();
            } catch (SQLException ex) {
                    Logger.getLogger(Functions.class.getName()).log(Level.SEVERE, null, ex);
            }
                                
            
            return sayac;
        }
    }
    
    public static void main(String[] args){
        
        Functions function = new Functions();
    
    }
    
}
