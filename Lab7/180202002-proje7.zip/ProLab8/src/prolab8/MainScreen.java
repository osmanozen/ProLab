package prolab8;

public class MainScreen extends javax.swing.JFrame {
    
    Functions function = new Functions();

    public MainScreen() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tedarikciEkle = new javax.swing.JButton();
        hammaddeIslemleri = new javax.swing.JButton();
        stoktakiler = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        mIslemler = new javax.swing.JButton();
        sIslemler = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tedarikciEkle.setText("Tedarikçi İşlemleri");
        tedarikciEkle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tedarikciEkleActionPerformed(evt);
            }
        });

        hammaddeIslemleri.setText("Hammadde İşlemleri");
        hammaddeIslemleri.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hammaddeIslemleriActionPerformed(evt);
            }
        });

        stoktakiler.setText("Stoktakiler");
        stoktakiler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stoktakilerActionPerformed(evt);
            }
        });

        jButton1.setText("Kimyasal Ürün İşlemleri");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        mIslemler.setText("Müşteri İşlemleri");
        mIslemler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mIslemlerActionPerformed(evt);
            }
        });

        sIslemler.setText("Sipariş İşlemleri");
        sIslemler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sIslemlerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(77, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(mIslemler, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(stoktakiler, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(tedarikciEkle, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE))
                .addGap(76, 76, 76)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(hammaddeIslemleri, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(sIslemler, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(97, 97, 97))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(mIslemler, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                    .addComponent(sIslemler, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hammaddeIslemleri, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tedarikciEkle, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(stoktakiler, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(195, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tedarikciEkleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tedarikciEkleActionPerformed
        
        TedarikciScreen tedarikciScreen = new TedarikciScreen(this,true);
        tedarikciScreen.setVisible(true);
    }//GEN-LAST:event_tedarikciEkleActionPerformed

    private void hammaddeIslemleriActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hammaddeIslemleriActionPerformed
        HammaddeScreen hammaddeScreen = new HammaddeScreen(this,true);
        hammaddeScreen.setVisible(true);
    }//GEN-LAST:event_hammaddeIslemleriActionPerformed

    private void stoktakilerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stoktakilerActionPerformed
        StokScreen stokScreen = new StokScreen(this,true);
        stokScreen.setVisible(true);
    }//GEN-LAST:event_stoktakilerActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        UrunScreen urunScreen = new UrunScreen(this,true);
        urunScreen.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void mIslemlerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mIslemlerActionPerformed
        MusteriScreen musteriScreen = new MusteriScreen(this,true);
        musteriScreen.setVisible(true);
    }//GEN-LAST:event_mIslemlerActionPerformed

    private void sIslemlerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sIslemlerActionPerformed
        SiparisScreen siparisScreen = new SiparisScreen(this,true);
        siparisScreen.setVisible(true);
    }//GEN-LAST:event_sIslemlerActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainScreen().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton hammaddeIslemleri;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton mIslemler;
    private javax.swing.JButton sIslemler;
    private javax.swing.JButton stoktakiler;
    private javax.swing.JButton tedarikciEkle;
    // End of variables declaration//GEN-END:variables
}
