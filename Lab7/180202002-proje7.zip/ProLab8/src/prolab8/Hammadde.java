package prolab8;

public class Hammadde {
    
    private int hammaddeID;
    private String firmaAdi;
    private String hammaddeAdi;
    private int hammaddeStok;
    private float hammaddeFiyat;
    private float hammaddeKargo;
    private String hammaddeUT;
    private int hammadeSKT;

    public Hammadde(int hammaddeID, String firmaAdi, String hammaddeAdi, int hammaddeStok, float hammaddeFiyat, float hammaddeKargo, String hammaddeUT, int hammadeSKT) {
        this.hammaddeID = hammaddeID;
        this.firmaAdi = firmaAdi;
        this.hammaddeAdi = hammaddeAdi;
        this.hammaddeStok = hammaddeStok;
        this.hammaddeFiyat = hammaddeFiyat;
        this.hammaddeKargo = hammaddeKargo;
        this.hammaddeUT = hammaddeUT;
        this.hammadeSKT = hammadeSKT;
    }

    public int getHammaddeID() {
        return hammaddeID;
    }

    public void setHammaddeID(int hammaddeID) {
        this.hammaddeID = hammaddeID;
    }

    public String getFirmaAdi() {
        return firmaAdi;
    }

    public void setFirmaAdi(String firmaAdi) {
        this.firmaAdi = firmaAdi;
    }

    public String getHammaddeAdi() {
        return hammaddeAdi;
    }

    public void setHammaddeAdi(String hammaddeAdi) {
        this.hammaddeAdi = hammaddeAdi;
    }

    public int getHammaddeStok() {
        return hammaddeStok;
    }

    public void setHammaddeStok(int hammaddeStok) {
        this.hammaddeStok = hammaddeStok;
    }

    public float getHammaddeFiyat() {
        return hammaddeFiyat;
    }

    public void setHammaddeFiyat(float hammaddeFiyat) {
        this.hammaddeFiyat = hammaddeFiyat;
    }

    public float getHammaddeKargo() {
        return hammaddeKargo;
    }

    public void setHammaddeKargo(float hammaddeKargo) {
        this.hammaddeKargo = hammaddeKargo;
    }

    public String getHammaddeUT() {
        return hammaddeUT;
    }

    public void setHammaddeUT(String hammaddeUT) {
        this.hammaddeUT = hammaddeUT;
    }

    public int getHammadeSKT() {
        return hammadeSKT;
    }

    public void setHammadeSKT(int hammadeSKT) {
        this.hammadeSKT = hammadeSKT;
    }

    
}
